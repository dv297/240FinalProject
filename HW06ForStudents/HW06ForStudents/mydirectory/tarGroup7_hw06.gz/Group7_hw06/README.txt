Homework 6 - CSCE 240 - Version 1.0
Last Updated: 16 April 2014
Submission Date: 24 April 2014
Authors: Daniel Vu, Collin Haines, Kevin Silver, Julio Diaz

Getting Started

    Mac OS X or Linux only:

    1. Open up Terminal.
    2. Navigate to where you're reading this README.txt file. (e.g. 'Downloads/', '~/')
    3. Compile all .cpp and .h files with:
    
       make

    4. Once compiling is complete run the program with:
    
       ./Aprog zin1.txt zoutx.txt zlogx.txt
       
    5. To read the output and/or the log file:
    
       cat zoutx.txt
       cat zlogx.txt
       
    6. For advanced users, (or users that want to have fun) change the input to any of the following:
    
       ./Aprog zin2.txt zoutx.txt zlogx.txt
       ./Aprog zin3.txt zoutx.txt zlogx.txt
       ./Aprog zin4.txt zoutx.txt zlogx.txt
       ./Aprog zinx.txt zoutx.txt zlogx.txt